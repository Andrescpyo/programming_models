package ui;

import abstractfactory.ElementosComunesFactory;
import builder.ResidenciaBuilder;
import clasesConcretas.Departamento;
import clasesConcretas.Piso;
import clasesConcretas.Residencia;
import prototype.ElementoComun;
import singleton.EmpresaConstructora;

import javax.swing.*;
import java.awt.*;

/**
 * """
 * Clase principal de la aplicación.
 * Se encarga de interactuar con el usuario para iniciar la construcción de residencias
 * y de utilizar los patrones de diseño implementados.
 * """
 */
public class Main {
    /**
     * """
     * Método principal de la aplicación.
     *
     * @param args Argumentos de la línea de comandos (no se utilizan en este caso).
     * """
     */
    public static void main(String[] args) {
        // Mostrar un diálogo de confirmación al usuario
        int result = JOptionPane.showConfirmDialog(null, "¿Deseas construir las residencias?", "Confirmación", JOptionPane.YES_NO_OPTION);

        // Si el usuario elige "Sí"
        if (result == JOptionPane.YES_OPTION) {
            // Crear una instancia de la fábrica de elementos comunes (Abstract Factory)
            ElementosComunesFactory factory = new ElementosComunesFactory();

            // Crear una instancia del constructor de residencias (Builder), pasando la fábrica
            ResidenciaBuilder builder = new ResidenciaBuilder(factory);

            // Crear tres residencias utilizando el Builder
            Residencia residencia1 = builder.construirResidencia("Residencia A");
            Residencia residencia2 = builder.construirResidencia("Residencia B");
            Residencia residencia3 = builder.construirResidencia("Residencia C");

            // Crear un único JTextArea para mostrar la información de todas las residencias
            JTextArea textArea = new JTextArea();
            textArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
            textArea.setEditable(false);

            // Obtener la instancia única de la EmpresaConstructora (Singleton) y construir las residencias
            EmpresaConstructora.getInstancia().construirResidencia(residencia1, textArea);
            EmpresaConstructora.getInstancia().construirResidencia(residencia2, textArea);
            EmpresaConstructora.getInstancia().construirResidencia(residencia3, textArea);

            // Mostrar la información de las residencias construidas en un JOptionPane
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(500, 400));
            JOptionPane.showMessageDialog(null, scrollPane, "Residencias Construidas", JOptionPane.INFORMATION_MESSAGE);
        }

        // Salir de la aplicación
        System.exit(0);
    }
}