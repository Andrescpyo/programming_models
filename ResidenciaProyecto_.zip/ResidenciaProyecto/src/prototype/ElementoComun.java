package prototype;

import javax.swing.JTextArea;

/**
 * """
 * Interfaz que define el contrato para los elementos comunes que pueden ser clonados.
 * Declara los métodos para clonar el objeto y para mostrar su información.
 *
 * Patrón Prototype:
 * Esta interfaz representa el 'Prototype'. Declara el método 'clonar()' que
 * todas las clases concretas que actúan como prototipos deben implementar.
 * """
 */
public interface ElementoComun extends Cloneable {
    /**
     * """
     * Método para crear una copia (clon) del objeto actual.
     * """
     */
    ElementoComun clonar();

    /**
     * """
     * Método para mostrar la información del elemento en un JTextArea.
     *
     * @param area El JTextArea donde se mostrará la información.
     * """
     */
    void mostrar(JTextArea area);
}