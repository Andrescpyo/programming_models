package abstractfactory;

import prototype.ElementoComun;

/**
 * """
 * Interfaz que define el contrato para las fábricas abstractas.
 * Cada fábrica concreta implementará esta interfaz para crear familias
 * de objetos relacionados (en este caso, elementos comunes de una construcción).
 *
 * Patrón Abstract Factory:
 * Esta interfaz representa la 'Abstract Factory'. Declara los métodos
 * para crear los productos abstractos (crearPuerta y crearVentana).
 * """
 */
public interface AbstractFactoryElementos {
    /**
     * """
     * Método abstracto para crear un objeto de tipo Puerta.
     * Las fábricas concretas proporcionarán la implementación específica.
     * """
     */
    ElementoComun crearPuerta();

    /**
     * """
     * Método abstracto para crear un objeto de tipo Ventana.
     * Las fábricas concretas proporcionarán la implementación específica.
     * """
     */
    ElementoComun crearVentana();
}