package builder;

import abstractfactory.AbstractFactoryElementos;
import clasesConcretas.Departamento;
import clasesConcretas.Piso;
import clasesConcretas.Residencia;
import prototype.ElementoComun;

/**
 * """
 * Clase Builder para la construcción de objetos Residencia de manera paso a paso.
 * Permite construir una residencia compleja sin exponer la lógica de creación
 * directamente en el cliente. Utiliza una Abstract Factory para crear los
 * elementos comunes de cada departamento.
 *
 * Patrón Builder:
 * Esta clase representa el 'Builder'. Define los pasos para construir un objeto
 * Residencia. En este caso, la construcción se realiza en el método
 * 'construirResidencia'.
 *
 * Relación con Abstract Factory:
 * El Builder utiliza una instancia de AbstractFactoryElementos (inyectada en el
 * constructor) para crear las Puertas y Ventanas de cada Departamento. Esto
 * desacopla la creación de los elementos de la lógica de construcción de la
 * Residencia, permitiendo cambiar fácilmente la familia de elementos utilizados
 * (por ejemplo, si tuviéramos otra fábrica para elementos de lujo).
 * """
 */
public class ResidenciaBuilder {
    /**
     * """
     * Referencia a la fábrica abstracta que se utilizará para crear
     * las puertas y ventanas de los departamentos.
     * """
     */
    private AbstractFactoryElementos factory;

    /**
     * """
     * Constructor del Builder que recibe una instancia de la fábrica abstracta.
     * Esto permite al Builder crear los elementos necesarios sin conocer
     * la implementación concreta de la fábrica.
     *
     * @param factory La fábrica abstracta para crear elementos comunes.
     * """
     */
    public ResidenciaBuilder(AbstractFactoryElementos factory) {
        this.factory = factory;
    }

    /**
     * """
     * Método principal para construir un objeto Residencia.
     * Define los pasos para crear los pisos y departamentos de la residencia,
     * utilizando la fábrica abstracta para crear las puertas y ventanas de cada departamento.
     *
     * @param nombre El nombre de la residencia a construir.
     * @return Una nueva instancia de Residencia construida.
     * """
     */
    public Residencia construirResidencia(String nombre) {
        // Paso 1: Crear la instancia de la Residencia
        Residencia residencia = new Residencia(nombre);

        // Paso 2: Construir los pisos
        for (int i = 1; i <= 3; i++) {
            Piso piso = new Piso("Piso " + i);

            // Paso 3: Construir los departamentos en cada piso
            for (int j = 1; j <= 2; j++) {
                Departamento depto = new Departamento("Depto " + j);

                // Paso 4: Utilizar la Abstract Factory para crear y agregar elementos al departamento
                ElementoComun puerta = factory.crearPuerta(); // Producto abstracto Puerta creado por la fábrica concreta
                depto.agregarElemento(puerta);
                ElementoComun ventana = factory.crearVentana(); // Producto abstracto Ventana creado por la fábrica concreta
                depto.agregarElemento(ventana);

                piso.agregarDepartamento(depto);
            }
            residencia.agregarPiso(piso);
        }

        // Paso 5: Devolver la residencia construida
        return residencia;
    }
}