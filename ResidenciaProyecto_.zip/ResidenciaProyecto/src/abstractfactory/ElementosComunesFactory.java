package abstractfactory;

import prototype.ElementoComun;
import prototype.Puerta;
import prototype.Ventana;

/**
 * """
 * Implementación concreta de la interfaz AbstractFactoryElementos.
 * Esta fábrica crea instancias de los elementos comunes estándar
 * (Puerta y Ventana de las clases concretas Puerta y Ventana).
 *
 * Patrón Abstract Factory:
 * Esta clase representa una 'Concrete Factory'. Implementa la interfaz
 * AbstractFactoryElementos y crea instancias de los productos concretos
 * (Puerta y Ventana).
 * """
 */
public class ElementosComunesFactory implements AbstractFactoryElementos {

    /**
     * """
     * Crea y devuelve una nueva instancia de la clase Puerta.
     * Esta es la implementación concreta para crear una puerta estándar.
     * """
     */
    @Override
    public ElementoComun crearPuerta() {
        return new Puerta();
    }

    /**
     * """
     * Crea y devuelve una nueva instancia de la clase Ventana.
     * Esta es la implementación concreta para crear una ventana estándar.
     * """
     */
    @Override
    public ElementoComun crearVentana() {
        return new Ventana();
    }
}