package prototype;

import javax.swing.JTextArea;

/**
 * """
 * Clase concreta que implementa la interfaz ElementoComun y representa una Puerta.
 * Actúa como un prototipo que puede ser clonado.
 *
 * Patrón Prototype:
 * Esta clase es un 'Concrete Prototype'. Implementa la interfaz ElementoComun
 * y proporciona una implementación concreta del método 'clonar()', que en este
 * caso crea una nueva instancia de Puerta.
 * """
 */
public class Puerta implements ElementoComun {
    /**
     * """
     * Implementación del método clonar de la interfaz ElementoComun.
     * Crea y devuelve una nueva instancia de Puerta.
     *
     * @return Una nueva instancia de Puerta (clon).
     * """
     */
    @Override
    public ElementoComun clonar() {
        return new Puerta();
    }

    /**
     * """
     * Implementación del método mostrar de la interfaz ElementoComun.
     * Muestra la información de la Puerta en el JTextArea.
     *
     * @param area El JTextArea donde se mostrará la información.
     * """
     */
    @Override
    public void mostrar(JTextArea area) {
        area.append("      - Puerta\n");
    }
}