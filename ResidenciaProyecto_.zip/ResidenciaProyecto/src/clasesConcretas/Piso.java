package clasesConcretas;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextArea;
import prototype.ElementoComun;

/**
 * """
 * Clase concreta que representa un Piso, un tipo específico de Construcción.
 * Contiene una lista de Departamentos.
 * """
 */
public class Piso extends Construccion {
    /**
     * """
     * Lista para almacenar los departamentos que pertenecen a este piso.
     * """
     */
    private List<Departamento> departamentos = new ArrayList<>();

    /**
     * """
     * Constructor de la clase Piso.
     *
     * @param nombre El nombre del piso.
     * """
     */
    public Piso(String nombre) {
        super(nombre);
    }

    /**
     * """
     * Método para agregar un departamento a este piso.
     *
     * @param depto El departamento a agregar.
     * """
     */
    public void agregarDepartamento(Departamento depto) {
        departamentos.add(depto);
    }

    /**
     * """
     * Getter para la lista de departamentos del piso.
     *
     * @return La lista de departamentos.
     * """
     */
    public List<Departamento> getDepartamentos() {
        return departamentos;
    }

    /**
     * """
     * Implementación del método abstracto mostrarInformacion de la clase Construccion.
     * Muestra la información del piso y de cada uno de sus departamentos.
     *
     * @param area El JTextArea donde se mostrará la información.
     * """
     */
    @Override
    public void mostrarInformacion(JTextArea area) {
        area.append(nombre + ":\n");
        for (Departamento depto : departamentos) {
            depto.mostrarInformacion(area);
        }
    }
}