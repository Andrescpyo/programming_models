package clasesConcretas;

import javax.swing.JTextArea;

/**
 * """
 * Clase abstracta que define la estructura base para cualquier tipo de construcción
 * (Residencia, Piso, Departamento). Proporciona un nombre común y un método
 * abstracto para mostrar información.
 * """
 */
public abstract class Construccion {
    /**
     * """
     * Nombre de la construcción.
     * """
     */
    protected String nombre;

    /**
     * """
     * Constructor de la clase Construccion.
     *
     * @param nombre El nombre de la construcción.
     * """
     */
    public Construccion(String nombre) {
        this.nombre = nombre;
    }

    /**
     * """
     * Getter para el nombre de la construcción.
     *
     * @return El nombre de la construcción.
     * """
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * """
     * Método abstracto para mostrar la información específica de cada tipo de construcción
     * en un JTextArea. Cada subclase debe implementar este método.
     *
     * @param area El JTextArea donde se mostrará la información.
     * """
     */
    public abstract void mostrarInformacion(JTextArea area);
}