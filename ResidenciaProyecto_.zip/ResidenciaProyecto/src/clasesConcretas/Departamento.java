package clasesConcretas;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextArea;
import prototype.ElementoComun;

/**
 * """
 * Clase concreta que representa un Departamento, un tipo específico de Construcción.
 * Contiene una lista de ElementosComunes (Puertas y Ventanas).
 * """
 */
public class Departamento extends Construccion {
    /**
     * """
     * Lista para almacenar los elementos comunes (Puertas y Ventanas) del departamento.
     * Estos elementos son creados por la Abstract Factory.
     * """
     */
    private List<ElementoComun> elementos = new ArrayList<>();

    /**
     * """
     * Constructor de la clase Departamento.
     *
     * @param nombre El nombre del departamento.
     * """
     */
    public Departamento(String nombre) {
        super(nombre);
    }

    /**
     * """
     * Método para agregar un elemento común (Puerta o Ventana) al departamento.
     * Los elementos agregados aquí son instancias creadas por la Abstract Factory
     * y potencialmente clonadas usando el Prototype.
     *
     * @param elemento El elemento común a agregar.
     * """
     */
    public void agregarElemento(ElementoComun elemento) {
        elementos.add(elemento);
    }

    /**
     * """
     * Getter para la lista de elementos comunes del departamento.
     *
     * @return La lista de elementos comunes.
     * """
     */
    public List<ElementoComun> getElementos() {
        return elementos;
    }

    /**
     * """
     * Implementación del método abstracto mostrarInformacion de la clase Construccion.
     * Muestra la información del departamento y de cada uno de sus elementos.
     *
     * @param area El JTextArea donde se mostrará la información.
     * """
     */
    @Override
    public void mostrarInformacion(JTextArea area) {
        area.append("    Departamento: " + nombre + "\n");
        for (ElementoComun e : elementos) {
            e.mostrar(area); // Llama al método mostrar del Prototype ElementoComun
        }
    }
}