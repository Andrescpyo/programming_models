package clasesConcretas;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextArea;

/**
 * """
 * Clase concreta que representa una Residencia, un tipo específico de Construcción.
 * Contiene una lista de Pisos. Esta clase es construida por el Builder.
 * """
 */
public class Residencia extends Construccion {
    /**
     * """
     * Lista para almacenar los pisos que componen la residencia.
     * """
     */
    private List<Piso> pisos = new ArrayList<>();

    /**
     * """
     * Constructor de la clase Residencia.
     *
     * @param nombre El nombre de la residencia.
     * """
     */
    public Residencia(String nombre) {
        super(nombre);
    }

    /**
     * """
     * Método para agregar un piso a la residencia.
     *
     * @param piso El piso a agregar.
     * """
     */
    public void agregarPiso(Piso piso) {
        pisos.add(piso);
    }

    /**
     * """
     * Getter para la lista de pisos de la residencia.
     *
     * @return La lista de pisos.
     * """
     */
    public List<Piso> getPisos() {
        return pisos;
    }

    /**
     * """
     * Implementación del método abstracto mostrarInformacion de la clase Construccion.
     * Muestra la información de la residencia y de cada uno de sus pisos.
     *
     * @param area El JTextArea donde se mostrará la información.
     * """
     */
    @Override
    public void mostrarInformacion(JTextArea area) {
        area.append(nombre + ":\n");
        for (Piso piso : pisos) {
            piso.mostrarInformacion(area);
        }
    }
}