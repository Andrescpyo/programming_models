package singleton;

import javax.swing.JTextArea;
import clasesConcretas.Residencia;

/**
 * """
 * Clase Singleton que representa la empresa constructora.
 * Asegura que solo exista una única instancia de esta clase en toda la aplicación.
 * Se utiliza para realizar operaciones a nivel de la empresa, como construir residencias.
 *
 * Patrón Singleton:
 * Esta clase implementa el patrón Singleton.
 * - Tiene un constructor privado para evitar la instanciación directa desde fuera de la clase.
 * - Mantiene una instancia estática de sí misma ('instancia').
 * - Proporciona un método estático ('getInstancia()') para acceder a la única instancia.
 * Este método se encarga de crear la instancia si aún no existe.
 * """
 */
public class EmpresaConstructora {
    /**
     * """
     * Instancia estática y única de la clase EmpresaConstructora.
     * Es inicializada a null y se crea la primera vez que se llama a getInstancia().
     * """
     */
    private static EmpresaConstructora instancia;

    /**
     * """
     * Constructor privado para asegurar que no se puedan crear instancias
     * de EmpresaConstructora desde fuera de esta clase.
     * """
     */
    private EmpresaConstructora() {}

    /**
     * """
     * Método estático para obtener la única instancia de EmpresaConstructora.
     * Si la instancia aún no existe, la crea.
     *
     * @return La única instancia de EmpresaConstructora.
     * """
     */
    public static EmpresaConstructora getInstancia() {
        if (instancia == null) {
            instancia = new EmpresaConstructora();
        }
        return instancia;
    }

    /**
     * """
     * Método para realizar la acción de construir una residencia.
     * Recibe la residencia a construir y el área de texto donde mostrar la información.
     *
     * @param residencia La residencia a construir.
     * @param area       El JTextArea donde se mostrará la información de la construcción.
     * """
     */
    public void construirResidencia(Residencia residencia, JTextArea area) {
        area.append("Construyendo residencia...\n");
        residencia.mostrarInformacion(area);  // ✅ lo pasa a la residencia
    }
}